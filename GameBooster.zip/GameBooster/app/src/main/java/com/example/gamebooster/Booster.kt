package com.example.gamebooster

import android.app.ActivityManager
import android.content.Context
import android.content.Intent

object Booster {
    /**
     * Menutup proses latar belakang aplikasi lain yang punya ikon launcher.
     * Android hanya mengizinkan proses yang memang sedang di latar belakang,
     * dan sistem bisa menjalankannya lagi. Mengembalikan jumlah aplikasi yang diminta ditutup.
     */
    fun run(ctx: Context): Int {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pkgs = ctx.packageManager.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName }
            .toSet() - ctx.packageName
        pkgs.forEach { am.killBackgroundProcesses(it) }
        ctx.cacheDir.deleteRecursively()
        return pkgs.size
    }
}
