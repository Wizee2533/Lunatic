package com.example.gamebooster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var stats: SystemStats
    private val handler = Handler(Looper.getMainLooper())
    private var panel: LinearLayout? = null
    private lateinit var cpu: GaugeView
    private lateinit var gpu: GaugeView
    private lateinit var temp: GaugeView
    private lateinit var fpsText: TextView
    private lateinit var info: TextView

    // FPS di sini = jumlah frame layar per detik yang dihitung Choreographer,
    // yaitu refresh rate tampilan, BUKAN FPS game lain.
    private var frames = 0
    private var lastNs = 0L
    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (lastNs == 0L) lastNs = ns
            frames++
            if (ns - lastNs >= 1_000_000_000L) {
                fpsText.text = "FPS $frames"
                frames = 0; lastNs = ns
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            val s = stats.read()
            cpu.value = s.cpu
            gpu.value = s.gpu
            temp.value = s.tempC?.roundToInt()
            info.text = "RAM %.1f/%.0f GB   ROM %.0f/%.0f GB   Baterai %s".format(
                s.ramUsedGb, s.ramTotalGb, s.romUsedGb, s.romTotalGb,
                s.battery?.let { "$it%" } ?: "--",
            )
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        if (panel == null) {
            wm = getSystemService(WindowManager::class.java)
            stats = SystemStats(this)
            showPanel()
            handler.post(tick)
            Choreographer.getInstance().postFrameCallback(frameCb)
        }
        return START_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showPanel() {
        cpu = GaugeView(this, "CPU", "%", 92)
        gpu = GaugeView(this, "GPU", "%", 92)
        temp = GaugeView(this, "Suhu HP", "°C", 92)
        fpsText = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; text = "FPS --" }
        info = TextView(this).apply { setTextColor(0xFFB7ABD8.toInt()); textSize = 11f }

        val title = TextView(this).apply {
            text = "Game Booster"; setTextColor(0xFF8B5CF6.toInt()); textSize = 16f
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val header = LinearLayout(this).apply { addView(title); addView(fpsText) }
        val gauges = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(cpu); addView(gpu); addView(temp)
        }
        val boost = Button(this).apply {
            text = "BOOST SEKARANG"; setTextColor(Color.WHITE)
            setBackgroundColor(0xFF6D28D9.toInt())
            setOnClickListener {
                val n = Booster.run(this@OverlayService)
                Toast.makeText(context, "Membersihkan $n aplikasi", Toast.LENGTH_SHORT).show()
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                setColor(0xEE0F0B1A.toInt()); cornerRadius = dp(16).toFloat()
                setStroke(dp(1), 0xFF2B2147.toInt())
            }
            addView(header); addView(gauges); addView(info); addView(boost)
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(24); y = dp(24) }

        // Geser panel dengan jari.
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(root, lp)
                }
            }
            true
        }
        wm.addView(root, lp)
        panel = root
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("booster", "Game Booster", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, "booster")
            .setContentTitle("Game Booster aktif")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        Choreographer.getInstance().removeFrameCallback(frameCb)
        panel?.let { wm.removeView(it) }
        panel = null
        super.onDestroy()
    }
}
