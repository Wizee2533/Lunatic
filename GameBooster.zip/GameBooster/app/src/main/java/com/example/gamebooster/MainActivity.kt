package com.example.gamebooster

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var stats: SystemStats
    private lateinit var cpu: GaugeView
    private lateinit var gpu: GaugeView
    private lateinit var temp: GaugeView
    private lateinit var info: TextView
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            val s = stats.read()
            cpu.value = s.cpu
            gpu.value = s.gpu
            temp.value = s.tempC?.roundToInt()
            info.text = "RAM %.1f / %.0f GB\nROM %.0f / %.0f GB\nBaterai %s".format(
                s.ramUsedGb, s.ramTotalGb, s.romUsedGb, s.romTotalGb,
                s.battery?.let { "$it%" } ?: "--",
            )
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        stats = SystemStats(this)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        cpu = GaugeView(this, "CPU", "%")
        gpu = GaugeView(this, "GPU", "%")
        temp = GaugeView(this, "Suhu HP", "°C")
        info = TextView(this).apply {
            setTextColor(0xFFB7ABD8.toInt()); textSize = 14f; gravity = Gravity.CENTER
        }
        val gauges = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(cpu); addView(gpu); addView(temp)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0F0B1A.toInt())
            setPadding(dp(16), dp(32), dp(16), dp(16))
            addView(TextView(context).apply {
                text = "Game Booster"; setTextColor(Color.WHITE); textSize = 24f
            })
            addView(gauges)
            addView(info)
            addView(button("Mulai panel overlay") { startOverlay() })
            addView(button("Hentikan panel overlay") {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            })
            addView(button("Boost sekarang") {
                val n = Booster.run(this@MainActivity)
                Toast.makeText(this@MainActivity, "Membersihkan $n aplikasi", Toast.LENGTH_SHORT).show()
            })
        }
        setContentView(root)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan 'Tampil di atas aplikasi lain', lalu coba lagi", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            startForegroundService(Intent(this, OverlayService::class.java))
        }
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.WHITE)
        setBackgroundColor(0xFF6D28D9.toInt())
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        setOnClickListener { onClick() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }
}
