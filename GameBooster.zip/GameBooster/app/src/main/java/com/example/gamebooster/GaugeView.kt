package com.example.gamebooster

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Gauge cincin 40 segmen, gaya dot-matrix ungu. value = 0..100, null tampil "--". */
class GaugeView(
    ctx: Context,
    private val label: String,
    private val unit: String,
    private val sizeDp: Int = 110,
) : View(ctx) {

    var value: Int? = null
        set(v) { field = v; invalidate() }

    private val d = resources.displayMetrics.density
    private val on = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8B5CF6.toInt(); strokeWidth = 3.5f * d; strokeCap = Paint.Cap.ROUND
    }
    private val off = Paint(on).apply { color = 0xFF3A2D66.toInt() }
    private val glass = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF150F26.toInt() }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textSize = sizeDp * 0.21f * d
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFA99BD0.toInt(); textAlign = Paint.Align.CENTER; textSize = 11f * d
    }

    override fun onMeasure(w: Int, h: Int) {
        val px = (sizeDp * d).toInt()
        setMeasuredDimension(px, px)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val outer = min(cx, cy) - 2 * d
        val inner = outer - 13 * d
        c.drawCircle(cx, cy, inner - 3 * d, glass)

        val filled = ((value ?: 0).coerceIn(0, 100) * SEG / 100f).roundToInt()
        for (i in 0 until SEG) {
            val a = Math.toRadians(-90.0 + i * 360.0 / SEG)
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            c.drawLine(
                cx + ca * inner, cy + sa * inner,
                cx + ca * outer, cy + sa * outer,
                if (i < filled) on else off,
            )
        }
        val text = value?.let { "$it$unit" } ?: "--"
        val base = cy + big.textSize * 0.1f
        c.drawText(text, cx, base, big)
        c.drawText(label, cx, base + 14 * d, small)
    }

    private companion object { const val SEG = 40 }
}
