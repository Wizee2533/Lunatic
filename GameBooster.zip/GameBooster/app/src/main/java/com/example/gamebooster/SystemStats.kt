package com.example.gamebooster

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import java.io.File

data class Snapshot(
    val cpu: Int?,          // persen, null jika tidak bisa dibaca
    val gpu: Int?,          // persen, null jika tidak bisa dibaca
    val tempC: Float?,      // suhu baterai (dipakai sebagai suhu HP)
    val battery: Int?,
    val ramUsedGb: Float,
    val ramTotalGb: Float,
    val romUsedGb: Float,
    val romTotalGb: Float,
)

class SystemStats(private val ctx: Context) {
    private var lastTotal = 0L
    private var lastIdle = 0L

    fun read(): Snapshot {
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            ?.takeIf { it != Int.MIN_VALUE }?.let { it / 10f }
        val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else null

        val mi = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val gb = 1024f * 1024f * 1024f

        val sf = StatFs(Environment.getDataDirectory().path)
        val romTotal = sf.blockCountLong * sf.blockSizeLong
        val romFree = sf.availableBlocksLong * sf.blockSizeLong

        return Snapshot(
            cpu = cpuFromProcStat() ?: cpuFromFreq(),
            gpu = gpuLoad(),
            tempC = temp,
            battery = pct,
            ramUsedGb = (mi.totalMem - mi.availMem) / gb,
            ramTotalGb = mi.totalMem / gb,
            romUsedGb = (romTotal - romFree) / gb,
            romTotalGb = romTotal / gb,
        )
    }

    // Android 8+ biasanya memblokir /proc/stat untuk aplikasi biasa.
    private fun cpuFromProcStat(): Int? = runCatching {
        val parts = File("/proc/stat").bufferedReader().use { it.readLine() }
            .trim().split(Regex("\\s+")).drop(1).map { it.toLong() }
        val idle = parts[3] + parts[4]
        val total = parts.sum()
        val dT = total - lastTotal
        val dI = idle - lastIdle
        val first = lastTotal == 0L
        lastTotal = total; lastIdle = idle
        if (first || dT <= 0) null else ((dT - dI) * 100 / dT).toInt()
    }.getOrNull()

    // Cadangan: perkiraan beban dari rasio frekuensi CPU saat ini terhadap maksimum.
    private fun cpuFromFreq(): Int? = runCatching {
        var sum = 0.0; var n = 0
        for (i in 0 until Runtime.getRuntime().availableProcessors()) {
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val cur = File(base + "scaling_cur_freq").readText().trim().toDouble()
            val max = File(base + "cpuinfo_max_freq").readText().trim().toDouble()
            if (max > 0) { sum += cur / max; n++ }
        }
        if (n == 0) null else (sum / n * 100).toInt()
    }.getOrNull()

    // Hanya jalan di sebagian HP Qualcomm; di kebanyakan HP akan null.
    private fun gpuLoad(): Int? = runCatching {
        File("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage").readText()
            .filter { it.isDigit() }.toInt()
    }.getOrNull()
}
