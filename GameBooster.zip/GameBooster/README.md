# Game Booster (Kotlin, tanpa library tambahan)

1. Buka folder ini di Android Studio (Hedgehog atau lebih baru), tunggu Gradle Sync.
2. Sambungkan HP (USB debugging) lalu klik Run, atau Build > Build APK(s).
3. Di aplikasi: ketuk "Mulai panel overlay", izinkan "Tampil di atas aplikasi lain".
   Panel bisa digeser dengan jari.

Catatan keterbatasan Android:
- FPS = refresh rate layar, bukan FPS game lain.
- CPU: dari /proc/stat bila bisa, jika tidak diperkirakan dari frekuensi CPU.
- GPU: hanya terbaca di sebagian HP Qualcomm, selain itu tampil "--".
- Suhu HP = suhu baterai.
